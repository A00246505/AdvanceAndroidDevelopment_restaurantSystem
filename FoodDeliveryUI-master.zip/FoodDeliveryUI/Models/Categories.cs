﻿using System;
namespace FoodDeliveryUI.Models
{
    public class Categories
    {
        public string Image { get; set; }
        public string Title { get; set; }
    }
}
